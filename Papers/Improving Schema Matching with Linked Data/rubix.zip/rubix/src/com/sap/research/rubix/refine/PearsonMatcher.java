package com.sap.research.rubix.refine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.xml.namespace.QName;

import org.json.JSONException;

import com.sap.research.amc.MatcherResources;
import com.sap.research.amc.matcher.AbstractMatcher;
import com.sap.research.amc.schema.Instance;

public class PearsonMatcher extends AbstractMatcher {

	final String PEARSON_MATCHER = "PEARSON_MATCHER";

	public PearsonMatcher(String name, MatcherResources resources) {
		super(name, resources);
	}

	@Override
	protected float executeMatchAlgorithm(int sourceElementId,
			int targetElementId) {

		// This needs to be a string since we don't send numbers to Freebase
		QName qn = new QName("String");
		if (!sourceSchemaElement(sourceElementId).getDataType().equals(qn)) {
			return SIMILARITY_UNKNOWN;
		}

		if (sourceSchemaElement(sourceElementId).getInstances().size() < 1) {
			return 0.0f;
		}
		if (targetSchemaElement(targetElementId).getInstances().size() < 1) {
			return 0.0f;
		}

		String[] sourceInstances = new String[sourceSchemaElement(
				sourceElementId).getInstances().size()];
		int i = 0;
		for (Instance instance : sourceSchemaElement(sourceElementId)
				.getInstances()) {
			sourceInstances[i] = instance.getValue();
			i++;
		}

		String[] targetInstances = new String[targetSchemaElement(
				targetElementId).getInstances().size()];
		i = 0;
		for (Instance instance : targetSchemaElement(targetElementId)
				.getInstances()) {
			targetInstances[i] = instance.getValue();
			i++;
		}

		float similarity = 0;
		try {
			similarity = calculateSimilarity(new StringBuilder().append("source_").append(sourceElementId).toString(),new StringBuilder().append("target_").append(targetElementId).toString(),sourceInstances, targetInstances);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return similarity;
	}

	/*
	 * This method compares query results for source cells with those for target
	 * cells. The result has to be between 0 and 1.
	 */

	private float calculateSimilarity(String sourceID, String targetID, String[] sourceResults, String[] targetResults) throws IOException, JSONException {

		float nom = 0;
		
		TreeMap<String, ArrayList<Object>> col1 = new ColumnRowsTypes().ColumnVector(sourceResults,sourceID);
		TreeMap<String, ArrayList<Object>> col2 = new ColumnRowsTypes().ColumnVector(targetResults,targetID);
		if (col1.size() >= col2.size()) {
			nom =  new ColumnSimilarity().pearsonSimilarity(col1.size(), col1, col2);
		} else {
			nom =  new ColumnSimilarity().pearsonSimilarity(col2.size(), col2, col1);
		}
		
		System.out.println("Pearson Similarity is : " + nom);
		return nom;
	}

	private static ArrayList<Object> addValues(ArrayList<Object> arrayList,
			Double value) {
		ArrayList<Object> toReturn = new ArrayList<Object>();
		toReturn.add(((Integer) arrayList.get(0)) + 1);
		toReturn.add((Double) arrayList.get(1) + value);
		return toReturn;
	}

	/*
	 * This method retrieves a set of results from Freebase based on a list of
	 * strings, in this case the column entries from a GR column. The treemap
	 * saves the results with the returned confidence values. A variant would be
	 * to save the position in the top N of results, i.e. 1st place gets weight
	 * N, 2nd gets N-1 etc.
	 */

	@SuppressWarnings("unused")
	private TreeMap<String, ArrayList<Object>> getFreebaseResults(
			String[] instances) throws IOException, JSONException {

		TreeMap<String, ArrayList<Object>> globalType = new TreeMap<String, ArrayList<Object>>();

		FreebaseReader JR = new FreebaseReader();

		for (int i = 0; i < instances.length; i++) {
			Iterator<Entry<String, Double>> it = JR.fetchTypes(instances[i])
					.entrySet().iterator();
			while (it.hasNext()) {
				Entry<String, Double> temp = it.next();
				if (globalType.containsKey(temp.getKey())) {
					globalType.put(
							temp.getKey(),
							addValues(globalType.get(temp.getKey()),
									temp.getValue()));
				} else {
					ArrayList<Object> values = new ArrayList<Object>();
					values.add(1);
					values.add(temp.getValue());
					globalType.put(temp.getKey(), values);
				}

			}
		}

		return globalType;
	}
}
