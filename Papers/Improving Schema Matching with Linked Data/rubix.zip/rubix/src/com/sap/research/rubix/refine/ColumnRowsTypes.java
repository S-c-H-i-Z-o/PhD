package com.sap.research.rubix.refine;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.json.JSONException;

public class ColumnRowsTypes {
	/**
	 * @param sourceElementId 
	 * @param args
	 * @throws JSONException
	 * @throws IOException
	 */
	public TreeMap<String, ArrayList<Object>> ColumnVector(String[] rows, String ID) throws IOException, JSONException {
		TreeMap<String, ArrayList<Object>> globalType;
		if (!RefineMatching.cacheMap.containsKey(ID)){
			globalType = new TreeMap<String, ArrayList<Object>>();
			FreebaseReader JR = new FreebaseReader();
			for (int i = 0; i < rows.length; i++) {
				Iterator<Entry<String, Double>> it = JR.fetchTypes(rows[i])
						.entrySet().iterator();
				while (it.hasNext()) {
					Entry<String, Double> temp = it.next();
					if (globalType.containsKey(temp.getKey())) {
						globalType.put(
								temp.getKey(),
								addValues(globalType.get(temp.getKey()),
										temp.getValue()));
					} else {
						ArrayList<Object> values = new ArrayList<Object>();
						values.add(1);
						values.add(temp.getValue());
						globalType.put(temp.getKey(), values);
					}
				}
				RefineMatching.cacheMap.put(ID, globalType);
			}
		} else {
			globalType = RefineMatching.cacheMap.get(ID);
			System.out.println("================ This entry is Cached ===================== ");
		}
		
		@SuppressWarnings("unused")
		double sum = 0;
		Iterator<Entry<String, ArrayList<Object>>> globalIterator = globalType
				.entrySet().iterator();
		System.out.println("Column " +  ID + " has the following types: ");
		while (globalIterator.hasNext()) {
			Entry<String, ArrayList<Object>> mapping = globalIterator.next();
			sum += ((Double) mapping.getValue().get(1));
		}
		return globalType;
	}

	private static ArrayList<Object> addValues(ArrayList<Object> arrayList,
			Double value) {
		ArrayList<Object> toReturn = new ArrayList<Object>();
		toReturn.add(((Integer) arrayList.get(0)) + 1);
		toReturn.add((Double) arrayList.get(1) + value);
		return toReturn;
	}
}
