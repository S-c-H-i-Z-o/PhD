package com.sap.research.rubix.refine;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;

import com.google.gson.stream.JsonWriter;
import com.google.refine.ProjectManager;
import com.google.refine.commands.Command;
import com.google.refine.model.Cell;
import com.google.refine.model.Column;
import com.google.refine.model.Project;
import com.google.refine.model.Row;
import com.sap.research.amc.MatcherFramework;
import com.sap.research.amc.MatcherResources;
import com.sap.research.amc.config.Config;
import com.sap.research.amc.mapping.Mapping;
import com.sap.research.amc.mapping.Match;
import com.sap.research.amc.matcher.NativeMatcherType;
import com.sap.research.amc.matcher.registry.MatcherRegistry;
import com.sap.research.amc.matcher.resources.dictionary.Dictionary;
import com.sap.research.amc.schema.Instance;
import com.sap.research.amc.schema.Schema;
import com.sap.research.amc.schema.SchemaElement;
import com.sap.research.amc.schema.SchemaFactory;

public class RefineMatching extends Command {
 
	static HashMap<String, TreeMap<String, ArrayList<Object>>> cacheMap = new HashMap<String, TreeMap<String, ArrayList<Object>>>();
	Project sourceProject;  // The current Source Project
	int index = 0; 			// Index used to name the key elements and give IDs in the JSON file
	String option = "No";	// Stores the option if the user wants to see all the unmatched results as well --> Default = No
	HashMap					//Stores the Set of schema elements
	<String, HashSet<String>> MappedElements = new HashMap<String, HashSet<String>>(); 
							//The Next variables are used to define the  --> Paths for icons used in the front end
							//Note that the path to put images in for JavaScript is [Refine Root]\main\webapp\modules\core\images
	String optionsIcon = "<img class=\"handcursor\" title=\"Show Details\" alt=\"Show Details\" src=\"images/details_open.png\">";
	String toolIcons =   "<img class=\"handcursor\" title=\"Match With Source\" alt=\"Match with Source\" src=\"images/arrow_right.png\"/>"
		+ "<span></span><img class=\"handcursor\" title=\"UnMatch Columns\" alt=\"UnMatch Columns\" src=\"images/delete.png\"/><span>"
		+ "</span><img class=\"handcursor\" title=\"Match With Target\" alt=\"Match with Target\" src=\"images/arrow_left.png\"/>"
		+ "<span>&nbsp;</span><img class=\"handcursor\" title=\"Delete\" alt=\"Delete\" src=\"images/cross.png\"/>";
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	};

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			ProjectManager.singleton.setBusy(true);
			sourceProject = getProject(request);
			Project targetProject = null;

			String targetProjectID = request.getParameter("targetProject");
			option = request.getParameter("option");
			if (targetProjectID != null) {
				long id = Long.parseLong(targetProjectID);
				targetProject = ProjectManager.singleton.getProject(id);
			}
			if (sourceProject == null) {
				sourceProject = getProject(request);
			}

			Schema sourceSchema = createSchema(sourceProject);
			Schema targetSchema = createSchema(targetProject);


			/*
			 * Try to automatically detect data types from column entries using setDataTypes
			 */
			
			setDataTypes(sourceSchema);
			setDataTypes(targetSchema);
			
			/*
			 * Hard-coded hack to resolve synonyms in the standard use case
			 */
			
			Dictionary dict = new Dictionary();
			/*
			 * NB: the important bit, here you choose the matching algorithms and configuration
			 */
			MatcherResources mr = new MatcherResources(sourceSchema,
					targetSchema, dict);
			List<NativeMatcherType> matcherTypes = new LinkedList<NativeMatcherType>();
			matcherTypes.add(NativeMatcherType.NAME);
			matcherTypes.add(NativeMatcherType.DATATYPE);
//			MatcherRegistry.getInstance().registerMatcherType("COSIN_MATCHER", CosinMatcher.class);
//			MatcherRegistry.getInstance().registerMatcherType("SPEARMAN_MATCHER", SpearmanMatcher.class);
//			MatcherRegistry.getInstance().registerMatcherType("PEARSON_MATCHER", PearsonMatcher.class);
			Config conf = MatcherFramework.getDefaultParallelConfig(matcherTypes);
			Config subConf = conf.getSubConfigs().get(0);
//			subConf.getSubConfigs().add(MatcherRegistry.getInstance().getDefaultConfiguration("COSIN_MATCHER"));
//			subConf.getSubConfigs().add(MatcherRegistry.getInstance().getDefaultConfiguration("SPEARMAN_MATCHER"));
//			subConf.getSubConfigs().add(MatcherRegistry.getInstance().getDefaultConfiguration("PEARSON_MATCHER"));
			
			Mapping mapping = MatcherFramework.getMapping(mr, conf);
			
			/*  We have a global Hashmap that stores two HashSets of Scheme Elements Names, if the user has 
			 *  chosen to show all Results including the unmatched ones, we will go through all the elements in that set, 
			 *  check if that element does not belong to a matched entry, and then include it in the JSON file
			 */
			
			System.out.println("======= Result is : ======= \n" + mapping);
			MappedElements.put("Source", new HashSet<String>());
			MappedElements.put("Target", new HashSet<String>());
			
			// Add all the source and target column names to the HashSet --> HashMap
			for (Match m : mapping.getMatches()) {
				MappedElements.get("Source").add(m.getSourceElement().getName());
				MappedElements.get("Target").add(m.getTargetElement().getName());
			}

			//This is the call for the function that creates the JSON
			/* response.getWriter : The writer that will perform the JSON creation
			 * mapping : The list of matches that will be displayed to the user
			 * Schemas that contains all the elements
			 */
			JSONify(response.getWriter(), mapping,sourceSchema,targetSchema);


		} catch (Exception e) {
			respondException(response, e);
		} finally {
			ProjectManager.singleton.setBusy(false);
		}
	}

	/* Basic Initialization of the writer --> The end result of the writer will be in the format :
	 * { 0: Object
			Extra_Information: Object {
				Source_Documentation: "No Documentation Available"
				Source_MaxCard: -1
				Source_MinCard: 0
				Target_Documentation: "No Documentation Available"
				Target_MaxCard: -1
				Target_MinCard: 0
				}	
			ID: "104"
			OptionsIcon: "<img class="handcursor" title="Show Details" alt="Show Details" src="images/details_open.png">"
			Similarity: "0.75"
			SourceColumn: "Source Name"
			SourceColumn_html: "<span id="source">Source Name</span>"
			TargetColumn: "Target Name"
			TargetColumn_html: "<span id="target">Target Name</span>"
			ToolsIcon: "<img class="handcursor" title="Match With Source" alt="Match with Source" ..... /> 
			} .... 
	 */
	
	public void JSONify(PrintWriter Responsewriter, Mapping maps, Schema sourceSchema, Schema targetSchema)
			throws IOException {
		JsonWriter writer = new JsonWriter(Responsewriter);
		writer.setIndent("       ");
		writeMainArray(writer, maps,sourceSchema,targetSchema);
		writer.close();
	}

	//This is the main writer that will start each entry`s JSON Data
	public void writeMainArray(JsonWriter writer, Mapping Mapping, Schema sourceSchema, Schema targetSchema) throws IOException {
		writer.beginArray();
		// Write the matched Elements
		for (Match match : Mapping.getMatches()) {
			//This condition is a filter that will discard Google Refine Added Columns that starts with "Column"
			if (!match.getSourceElement().getName().startsWith("Column") && !match.getTargetElement().getName().startsWith("Column"))
				//Call for the function that will write the details
				writeMatches(writer, match);
		}
		// This is the check if the user wants to see all the results returned from AMC
		if (option.equals("Yes")) {
			System.out.println(" ---> The user selected to View all Results suggested by the System ....  \n");
			for (SchemaElement e : sourceSchema.getAllElements()) {
				//Check if the source element is not mapped
				if (!MappedElements.get("Source").contains(e.getName())) {
					writeUnMatched(writer, e, "Source");
				}
			}
			for (SchemaElement e : targetSchema.getAllElements()) {
				//Check if the target element is not mapped
				if (!MappedElements.get("Target").contains(e.getName())) {
					writeUnMatched(writer, e, "Target");
				}
			}
		}
		writer.endArray();
	}

	/* The main JSON writing function that will write the main details
	 * Each JSON object will have the name and the value together so that elements can be accessed via their names 
	 */
	
	public void writeMatches(JsonWriter writer, Match match) throws IOException {
		
		writer.beginObject();
		writer.name("ID").value(Integer.toString(index));
		writer.name("SourceColumn_html").value("<span id=\"source\">" + match.getSourceElement().getName()+ "</span>");
		writer.name("TargetColumn_html").value("<span id=\"target\">" + match.getTargetElement().getName()+ "</span>");
		writer.name("Similarity").value(Float.toString(match.getSimilarity()));
		writer.name("SourceColumn").value(match.getSourceElement().getName());
		writer.name("TargetColumn").value(match.getTargetElement().getName());
		writer.name("OptionsIcon").value(optionsIcon);
		writer.name("ToolsIcon").value(toolIcons);
		writer.name("Source_Datatype");
		writeDataTypes(writer, match.getSourceElement().getName());
		writer.name("Extra_Information");
		writeExtraInfo(writer, match); //This is the call for another writer that will write the Extra information inner array
		writer.endObject();
		index++;
	}

	public void writeUnMatched(JsonWriter writer, SchemaElement element,
			String type) throws IOException {
		writer.beginObject();
		writer.name("ID").value(Integer.toString(index));
		if (type.equals("Source")) {
			writer.name("SourceColumn_html").value( "<span id=\"source\">" + element.getName() + "</span>");
			writer.name("SourceColumn").value(element.getName());
		} else {
			writer.name("SourceColumn_html").value("<span id=\"source\" class=\"toEdit\"></span>");
			writer.name("SourceColumn").nullValue();
		}
		if (type.equals("Target")) {
			writer.name("TargetColumn_html").value("<span id=\"target\">" + element.getName() + "</span>");
			writer.name("TargetColumn").value(element.getName());
		} else {
			writer.name("TargetColumn_html").value("<span id=\"target\" class=\"toEdit\"></span>");
			writer.name("TargetColumn").nullValue();
		}
		writer.name("Similarity").value("-");
		writer.name("OptionsIcon").value(optionsIcon);
		writer.name("ToolsIcon").value(toolIcons);
		writer.name("Source_Datatype");
		writeDataTypes(writer, element.getName());
		writer.name("Extra_Information");
		writeUnmatchedExtraInfo(writer);
		writer.endObject();
		index++;
	}
	
	/* This function will write the Extra details for every entry, It will check if the documentation exists or else
	 * it will simply write "No Documentation Available"
	 */
	public void writeExtraInfo(JsonWriter writer, Match match)throws IOException {
		writer.beginObject();
		if (match.getSourceElement().getDocumentation() == null) { //Check if no source documentation is available
			writer.name("Source_Documentation").value("No Documentation Available");
		} else {
			writer.name("Source_Documentation");
			writeDocumentation(writer, match.getSourceElement() .getDocumentation());
		}
		if (match.getSourceElement().getDocumentation() == null) { //Check if no target documentation is available
			writer.name("Target_Documentation").value( "No Documentation Available");
		} else {
			writer.name("Target_Documentation");
			writeDocumentation(writer, match.getTargetElement().getDocumentation());
		}
		// Here we can write all the extra information needed --> Simply add a name and a corresponding value
		writer.name("Source_MaxCard").value(match.getSourceElement().getMaxCard());
		writer.name("Target_MaxCard").value(match.getTargetElement().getMaxCard());
		writer.name("Source_MinCard").value(match.getSourceElement().getMinCard());
		writer.name("Target_MinCard").value(match.getTargetElement().getMinCard());
		writer.endObject();
	}
	
	/* This function write the extra information array for the unmatched elements
	 * There is no documentation available but we want to show some message in the front end in case the 
	 * user wished to enter his own documentation to be saved later
	 */
	public void writeUnmatchedExtraInfo(JsonWriter writer)
			throws IOException {
		writer.beginObject();
		writer.name("Source_Documentation").value("No Documentation Available");
		writer.name("Target_Documentation").value("No Documentation Available");
		writer.endObject();
	}
	
	// This is where documentation is written as it is an array of strings
	public void writeDocumentation(JsonWriter writer, String[] documentation)
			throws IOException {
		writer.beginArray();
		for (String value : documentation) {
			writer.value(value);
		}
		writer.endArray();
	}
	
	public void writeDataTypes(JsonWriter writer, String columnName)
			throws IOException {		
		writer.beginArray();
		for (String value : getDatatypes(columnName)) {
			writer.value(value);
		}
		writer.endArray();
	}

	public HashSet<String> getDatatypes(String columnName) {
		HashSet<String> datatypes = new HashSet<String>();
		int columnIndex = sourceProject.columnModel
				.getColumnIndexByName(columnName);
		for (int row = 0; row < sourceProject.rows.size(); row++) {
			Cell cell = sourceProject.rows.get(row).getCell(columnIndex);
			if (cell != null && !cell.toString().isEmpty()) {
				datatypes.add(cell.value.getClass().toString());
			}
		}
		return datatypes;
	}
	/**
	 * Creates a complete schema including elements and instances of elements
	 * from the Google Refine project that is passed as argument.
	 * 
	 * @param project
	 * @return
	 */

	private Schema createSchema(Project project) {

		List<String> columnNames = project.columnModel.getColumnNames();

		Schema schema = SchemaFactory.eINSTANCE.createSchema();
		schema.setName(project.getMetadata().getName());

		try {
			schema.setUri(new URI("http://sap.com/test"));
		} catch (URISyntaxException e3) {
			e3.printStackTrace();
		}

		// Create schema elements, start with root and subsequently add children
		SchemaElementExtended root = new SchemaElementExtended();
		root.setName(project.getMetadata().getName());
		schema.getAllElements().add(root);

		for (String column : columnNames) {
			SchemaElementExtended element = new SchemaElementExtended();

			element.setName(column);
			Column col = project.columnModel.getColumnByName(column);
			if (null != col) {
				int index = col.getCellIndex();

				for (Row row : project.rows) {
					Cell cell = row.getCell(index);
					if (null != cell) {

						String cellType = cell.value.getClass().getSimpleName();
						String cellName = cell.value.toString();
						Instance instance = SchemaFactory.eINSTANCE
								.createInstance();
						instance.setValue(cellName);
						element.getInstances().add(instance);
						if (!element.getRecognizedTypes().containsKey(cellType)) {
							element.getRecognizedTypes().put(cellType, 1);
						} else {
							int i = element.getRecognizedTypes().get(cellType);
							element.getRecognizedTypes().put(cellType, i + 1);
						}

					}
				}
			}

			root.getChildren().add(element);
		}
		return schema;
	}

	/**
	 * This tries to extract data types from the recognized instances. This is
	 * still very basic.
	 * 
	 * @param schema
	 */

	private void setDataTypes(Schema schema) {
		
		for (SchemaElement se : schema.getAllElements()) {		
			if (se instanceof SchemaElementExtended) {
				if (((SchemaElementExtended) se).getRecognizedTypes()
						.containsKey("Date")) {
					se.setDataType(new QName("Date"));
				} else if (((SchemaElementExtended) se).getRecognizedTypes()
						.containsKey("Double")) {
					se.setDataType(new QName("Double"));
				} else {
					se.setDataType(new QName("String"));
				}
			}
		}
	}
}
