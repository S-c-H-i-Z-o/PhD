package com.sap.research.rubix.refine;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.commons.math.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math.stat.correlation.SpearmansCorrelation;

public class ColumnSimilarity {
	
	public float calculateNominator(TreeMap<String, ArrayList<Object>> col1,
			TreeMap<String, ArrayList<Object>> col2) {
		float crossColumns = 0;
		Iterator<Entry<String, ArrayList<Object>>> mapIterator = col1.entrySet().iterator();
		while(mapIterator.hasNext()) {
			Entry<String, ArrayList<Object>> mapping = mapIterator.next();
			if (col2.containsKey(mapping.getKey())) {
				crossColumns += (Double)col2.get(mapping.getKey()).get(1) * (Double)mapping.getValue().get(1);
			} 
		}		
		return crossColumns;

	}
	
	public float calculateColumnNorm(TreeMap<String, ArrayList<Object>> col) {
		float colNorm = 0;
		Iterator<Entry<String, ArrayList<Object>>> mapIterator = col.entrySet().iterator();
		while(mapIterator.hasNext()) {
			Entry<String, ArrayList<Object>> mapping = mapIterator.next();
			colNorm += (Double)mapping.getValue().get(1) * (Double)mapping.getValue().get(1);
		}
		return (float) Math.sqrt(colNorm);		
	}
	public float pearsonSimilarity(int size,
			TreeMap<String, ArrayList<Object>> col1,
			TreeMap<String, ArrayList<Object>> col2) {
		double[] x = new double[size];
		double[] y = new double[size];
		Iterator<Entry<String, ArrayList<Object>>> globalIterator = col1
				.entrySet().iterator();
		int index = 0;
		while (globalIterator.hasNext()) {
			Entry<String, ArrayList<Object>> mapping = globalIterator.next();
			x[index] = (Double) mapping.getValue().get(1);
			if (col2.containsKey(mapping.getKey())) {
				y[index] = (Double) col2.get(mapping.getKey()).get(1);
			} else {
				y[index] = 0;
			}
			index++;
		}
		return (float) new PearsonsCorrelation().correlation(x, y) ;
	}
	
	public float spearmanSimilarity(int size,TreeMap<String, ArrayList<Object>> col1,TreeMap<String, ArrayList<Object>> col2) {
		double[] x = new double[size]; double[]y = new double[size];
		Iterator<Entry<String, ArrayList<Object>>> globalIterator = col1.entrySet().iterator();
		int index = 0;
		while (globalIterator.hasNext()) {
			Entry<String, ArrayList<Object>> mapping = globalIterator.next();
			x[index] = (Double)mapping.getValue().get(1);
			if (col2.containsKey(mapping.getKey())) {
				y[index] = (Double) col2.get(mapping.getKey()).get(1);
			} else {
				y[index] = 0;
			}
			index++;
		}
	return (float) new SpearmansCorrelation().correlation(x, y);
	}
	
}
