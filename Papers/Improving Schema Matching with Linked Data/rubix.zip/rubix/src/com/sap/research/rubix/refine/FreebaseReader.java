package com.sap.research.rubix.refine;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FreebaseReader {
	
	static HashMap<String, HashMap<String, Double>> rowsCache = new HashMap<String, HashMap<String,Double>>();
	String freebaseAddress = "https://www.googleapis.com/freebase/v1/search?query=";
	
	private String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public JSONObject readJsonFromUrl(String url) throws IOException,
			JSONException {
		InputStream is = new URL(url).openStream();
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is,
					Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			JSONObject json = new JSONObject(jsonText);
			return json;
		} finally {
			is.close();
		}
	}

	public HashMap<String, Double> fetchTypes(String keyword) throws IOException, JSONException {
		HashMap<String, Double> rich_types;
		System.setProperty("https.proxyHost", "proxy");
		System.setProperty("https.proxyPort", "8080");
		if (!rowsCache.containsKey(keyword)) {
			JSONObject json = readJsonFromUrl(freebaseAddress + keyword.replaceAll(" ", "%20"));
			rich_types = new HashMap<String, Double>();
			JSONArray array = json.getJSONArray("result");
			for (int i = 0; i < array.length(); i++) {
				if (array.getJSONObject(i).has("notable")) {
					JSONObject notable = new JSONObject(array.getJSONObject(i)
							.getString("notable"));
					if (!rich_types.containsKey(notable.getString("name"))){
						rich_types.put(notable.getString("name"), (Double) array.getJSONObject(i).get("score"));
						rowsCache.put(keyword, rich_types);
					}
				}
			}
		} else {
			rich_types = rowsCache.get(keyword);
			System.out.print("[ Row Cached ]");
		}
		System.out.print(" The Result for " + keyword + " is: ");
		System.out.println(rich_types);
		return rich_types;
	}

}
