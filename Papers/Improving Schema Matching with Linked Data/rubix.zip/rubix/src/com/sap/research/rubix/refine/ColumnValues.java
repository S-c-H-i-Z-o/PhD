package com.sap.research.rubix.refine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONWriter;

import com.google.gson.Gson;
import com.google.refine.ProjectManager;
import com.google.refine.commands.Command;
import com.google.refine.model.Cell;
import com.google.refine.model.Project;


public class ColumnValues extends Command {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	};

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			ProjectManager.singleton.setBusy(true);
			Project project = getProject(request);
			String[] columnNames = getColumnNames(request);
	        String[] monthName = {"January", "February",
	                "March", "April", "May", "June", "July",
	                "August", "September", "October", "November",
	                "December"};
	     
			JSONWriter writer = new JSONWriter(response.getWriter());
			writer.object();
			
			try {
				System.out.println("Getting Values");
				int columnIndex = project.columnModel
						.getColumnIndexByName(columnNames[0]);
				Calendar cal = Calendar.getInstance();
				ArrayList<String> keysList = new ArrayList<String>();				
				HashMap<String, ArrayList<Float>> values = new HashMap<String, ArrayList<Float>>();
				String key;
				for (int row = 0; row < project.rows.size(); row++) {
					Cell cell = project.rows.get(row).getCell(columnIndex);
					if (cell != null && !cell.toString().isEmpty()) {						
						if (cell.value instanceof Date) {
							cal.setTime((Date) cell.value);
							String month = monthName[cal.get(Calendar.MONTH)];
							int year = cal.get(Calendar.YEAR);
							key = month + " " + year;
						} else { 
							key = cell.toString();
						}
							ArrayList<Float> vals = new ArrayList<Float>();
							for (int c = 1; c < columnNames.length; c++) {
								int Index = project.columnModel.getColumnIndexByName(columnNames[c]);
								if (project.rows.get(row).getCell(Index) != null && !project.rows.get(row).getCell(Index).toString().isEmpty()) {
									vals.add(Float.valueOf(project.rows.get(row).getCell(Index).toString()).floatValue());
								}								
							}
							if (values.containsKey(key)) {
								values.put(key,arrayListAddition(values.get(key), vals));
							} else {
								keysList.add(key);
								values.put(key, vals);
							}
						}
				}	
				writer.key("Categories");	
				writer.array();	
				for  (int index=0; index < keysList.size();index++) {					
					writer.value(keysList.get(index));					
				}
				writer.endArray();
				for (int index = 1; index < columnNames.length ; index++) {
					writer.key(columnNames[index]);	
					writer.array();
					for (int i = 0; i < keysList.size(); i++){
						System.out.print("Printing Values for : " + keysList.get(i)+" ");				
						printList(values.get(keysList.get(i)));
						writer.value(values.get(keysList.get(i)).get(index-1));
					}
					writer.endArray();
				}

			} catch (Exception e) {
				System.err.println("Sth Bad Happened !! :(");
				e.printStackTrace();
			}
			writer.endObject();
		} catch (Exception e) {
			respondException(response, e);
		} finally {
			ProjectManager.singleton.setBusy(false);
		}
	}
	
	public void printList(ArrayList<Float> list){
			for (int index = 0; index < list.size(); index++) {
				System.out.print(" - " + list.get(index));
			}
			System.out.println(" -->");
	
	}

	public ArrayList<Float> arrayListAddition(ArrayList<Float> A,
			ArrayList<Float> B) {
		ArrayList<Float> c = new ArrayList<Float>();
		for (int i = 0; i < A.size(); i++) {
			System.out.println("Printing Value A" + A.get(i));
			System.out.println("Printing Value B" +  B.get(i));
			c.add(A.get(i) + B.get(i));
		}
		return c;

	}

	public String[] getColumnNames(HttpServletRequest request) {
		String json = request.getParameter("columns");
		Gson gson = new Gson();
		String[] columnNames = gson.fromJson(json, String[].class);
		return columnNames;
	}
}
