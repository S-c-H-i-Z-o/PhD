package com.sap.research.rubix.refine;

public class ColumnMatch {

	private String oldSource;
	private String oldTarget;
	private String newColumn;
	
	public ColumnMatch(String a, String b, String c){
		this.oldSource = a;
		this.oldTarget = b;
		this.newColumn = c;
	}
	
	public String getOldSource() {
		return oldSource;
	}
	public void setOldSource(String oldSource) {
		this.oldSource = oldSource;
	}
	public String getOldTarget() {
		return oldTarget;
	}
	public void setOldTarget(String oldTarget) {
		this.oldTarget = oldTarget;
	}
	public String getNewColumn() {
		return newColumn;
	}
	public void setNewColumn(String newColumn) {
		this.newColumn = newColumn;
	}
	
}
