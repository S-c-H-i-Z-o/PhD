function charting(response){
	var options = {
			chart: {
				renderTo: 'container',
				defaultSeriesType: 'column'
			},
			title: {
				text: 'Total Expenses'
			},
			xAxis: {
				categories: cat
			},
			yAxis: {
				min: 0,
				title: {
					text: 'Expenses (USD)'
				}
			},
			legend: {
				layout: 'vertical',
				backgroundColor: '#FFFFFF',
				align: 'right',
				verticalAlign: 'top',
				x: 0,
				y: 70,
				floating: true,
				shadow: true
			},
			tooltip: {
				formatter: function() {
					return ''+
						this.x +': '+ this.y +' USD';
				}
			},
			plotOptions: {
				column: {
					pointPadding: 0.2,
					borderWidth: 0
				}
			},
			series: []
		};
	for (var i= 0 ; i < columnsArray.length; i++) {
		if (columnsArray[i] != "Date" && columnsArray[i] != "Country" && columnsArray[i] != "Contry" && columnsArray[i] != "Dates") {
			options.series.push({
				name : columnsArray[i],
				data : chartingData[i]
			});
		}
	}
	
	chart = new Highcharts.Chart(options);

}