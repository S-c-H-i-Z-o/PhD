/*  This is the first dialog that is shown in the work-flow
	The user is upon selection the first menu option will be presented with the list of projects available in Google
	Refine, Upon Selection of a project the second Dialog is Shown and the current dialog is dismissed
*/

var elmts;	//Global Variable that holds the DOM elements
var oTable; //Global Element that will save the Datatable

function matchingDialog() {
	this._createDialog();
}

matchingDialog.prototype._createDialog = function() {
	var self = this;
	var dialog = $(DOM.loadHTML("amc-refine",
			"scripts/dialogs/matching-dialog.html"));
	elmts = DOM.bind(dialog);
	var level = DialogSystem.showDialog(dialog);
	var dismiss = function() {
		DialogSystem.dismissUntil(level - 1);
	};

	elmts.match.click(function() {
		var anSelected = fnGetSelected(oTable);
		if (!anSelected[0]) {
			alert("Please Select a Project");
		} else {
			// a workaround for a flaw in the demo system (http://dev.jqueryui.com/ticket/4375), ignore!
			$( "#dialog:ui-dialog" ).dialog( "destroy" );		
			$( "#dialog-confirm" ).dialog({
				resizable: false,
				height:140,
				modal: true,
				buttons: {
					"Yes": function() {
						$(this).dialog( "close" );
						dismiss();
						AmcExtension.handlers.prepAmcDialog(anSelected[0],"Yes");
					},
					"No": function() {
						$(this).dialog( "close" );
						dismiss();
						AmcExtension.handlers.prepAmcDialog(anSelected[0],"No");
					}
				}
			});
		}
	});
	elmts.cancelButton.click(function() {
		dismiss();
	});

	//Getting back the row selected and returning the Project ID
	function fnGetSelected(oTableLocal) {
		var aReturn = new Array();
		var aTrs = oTableLocal.fnGetNodes();
		for ( var i = 0; i < aTrs.length; i++) {
			if ($(aTrs[i]).hasClass('row_selected')) {
				var aData = oTableLocal.fnGetData(aTrs[i]);
				aReturn.push(aData[0]);
			}
		}
		return aReturn;
	}
	
	//Getting the JSON from the servlet with the Projects MetaData
	$.getJSON("/command/core/get-all-project-metadata", null, function(data) {
		self._renderProjects(data);
	}, "json");
};

matchingDialog.prototype._renderProjects = function(data) {
	var projects = [];
	for ( var n in data.projects) {
		if (data.projects.hasOwnProperty(n)) {
			var project = data.projects[n];
			var modified = Date.parseExact(project.modified,
					"yyyy-MM-ddTHH:mm:ssZ");
			var date = modified.toString().split("G");
			projects.push([ n, project.name, date[0] ]);
		}
	}

	if (!projects.length) {
		alert("No Saved Projects Were Found !! ");
	}

	//Initializing the Datatable with the Projects and Creation Dates
	$(elmts.dialogTable).dataTable({
		"sScrollY" : 200,
		"sScrollX" : "100%",
		"sScrollXInner" : "100%",
		"sPaginationType" : "full_numbers",
		"aaData" : projects,
		"bDeferRender": true,
		"aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
		"aoColumns" : [ {
			"sTitle" : "Project ID"
		}, {
			"sTitle" : "Project Name"
		}, {
			"sTitle" : "Modified Date",
			"sClass" : "center"
		} ],
		"aoColumnDefs" : [ {
			"bSearchable" : false,
			"bVisible" : false,
			"aTargets" : [ 0 ]
		} ],
		"aaSorting" : [ [ 1, 'asc' ] ]
	});

	$(elmts.dialogTable).find('tbody').click(function(event) {
		$(oTable.fnSettings().aoData).each(function() {
			$(this.nTr).removeClass('row_selected');
		});
		$(event.target.parentNode).addClass('row_selected');
	});
	oTable = $(elmts.dialogTable).dataTable();
};
