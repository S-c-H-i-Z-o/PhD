function removeByElement(arrayName,arrayElement)
 {
  for(var i=0; i<arrayName.length;i++ )
   { 
  if(arrayName[i]==arrayElement)
  arrayName.splice(i,1); 
  } 
  }
  
  function inArray( elem, array, bool ) {
	var ret = -1;
	if ( array.indexOf ) {
		ret = array.indexOf( elem );
	} else {
		for ( var i = 0, length = array.length; i < length; i++ ) {
			if ( array[ i ] === elem ) {
				ret = i;
				break;
			}
		}	
	}
	if( bool === true ){
		return ret !== -1;
	} else {
		return ret;	
	}
}
