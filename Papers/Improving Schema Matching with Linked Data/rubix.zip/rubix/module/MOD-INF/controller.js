var html = "text/html";
var encoding = "UTF-8";
var ClientSideResourceManager = Packages.com.google.refine.ClientSideResourceManager;

/*
 * Function invoked to initialize the extension.
 */
function init() {

	Packages.java.lang.System.err.println("Initializing RUBIX Enhanced Extension - File controller.js");
    var RS = Packages.com.google.refine.RefineServlet;
    RS.registerCommand(module, "amc-refine", new Packages.com.sap.research.rubix.refine.RefineMatching());
    RS.registerCommand(module, "merge-projects", new Packages.com.sap.research.rubix.refine.MergeProjects());
    RS.registerCommand(module, "get-column-values", new Packages.com.sap.research.rubix.refine.ColumnValues());

    
    // Script files to inject into /project page
    ClientSideResourceManager.addPaths(
        "project/scripts",
        module,
        [
            "scripts/project-injection.js",
			
            "scripts/dialogs/matching-dialog.js",
			"scripts/dialogs/amc-dialog.js",
			
			"scripts/dialogs/require/jquery.dataTables.min.js",
			"scripts/dialogs/require/api.dataTable.js",
			"scripts/dialogs/require/jquery.jeditable.js",
			"scripts/dialogs/require/highcharts.js",
			
			"scripts/functions/core.js",
			
			"scripts/dialogs/functions/matching-table.js",
			"scripts/dialogs/functions/drag_drop.js",
			"scripts/dialogs/functions/chartsGallery.js",
			"scripts/dialogs/functions/chart.js",
        ]
    );
    
    // Style files to inject into /project page
    ClientSideResourceManager.addPaths(
        "project/styles",
        module,
        [
			"styles/style.css"
        ]
    );

}

/*
 * Function invoked to handle each request in a custom way.
 */
function process(path, request, response) {
  // Analyze path and handle this request yourself.
	var loggerFactory = Packages.org.slf4j.LoggerFactory;
	var logger = loggerFactory.getLogger("amc-refine");
    var method = request.getMethod();

	logger.info('receiving request for ' + path);
	
    if (path == "/" || path == "") {
    	butterfly.redirect(request, response, "index.html");
    }
}

function send(request, response, template, context) {
  butterfly.sendTextFromTemplate(request, response, context, template, encoding, html);
}
