function dragAndDrop() {
	   var selectedClass = 'ui-state-highlight',
	    clickDelay = 200,     // click time (milliseconds)
	    lastClick, diffClick; // timestamps

		$("ul.droptrue li")
		    // Script to deferentiate a click from a mousedown for drag event
		    .bind('mousedown mouseup', function(e){
		        if (e.type=="mousedown") {
		            lastClick = e.timeStamp; // get mousedown time
		        } else {
		            diffClick = e.timeStamp - lastClick;
		            if ( diffClick < clickDelay ) {
		                // add selected class to group draggable objects
		                $(this).toggleClass(selectedClass);
		            }
		        }
		    })
		    .draggable({
		        revertDuration: 10, // grouped items animate separately, so leave this number low
		        containment: '.multiSelect',
		        start: function(e, ui) {
		            ui.helper.addClass(selectedClass);
		        },
		        stop: function(e, ui) {
		            // reset group positions
		            $('.' + selectedClass).css({ top:0, left:0 });
		        },
		        drag: function(e, ui) {
		            // set selected group position to main dragged object
		            // this works because the position is relative to the starting position
		            $('.' + selectedClass).css({
		                top : ui.position.top,
		                left: ui.position.left
		            });
		        }
		    });

		$("ul.droptrue")
		    .sortable({
		    	cancel: "div[class^=instructions]"
		    })
		    .droppable({
		        drop: function(e, ui) {
		            $('.' + selectedClass)
		             .appendTo($(this))
		             .add(ui.draggable) // ui.draggable is appended by the script, so add it after
		             .removeClass(selectedClass)
		             .css({ top:0, left:0 });
		        }
		    });
		
		$('#total').text(autoCompleteArray[0].length);
		$('#filter-count').text(autoCompleteArray[0].length);
		//Adding Filtering functionality for the lists
		$("#filter").keyup(function () {
		    var filter = $(this).val(), count = 0;
		    $("ul.droptrue:first li").each(function () {
		        if ($(this).text().search(new RegExp(filter, "i")) < 0) {
		            $(this).addClass("hidden");
		        } else {
		            $(this).removeClass("hidden");
		            count++;
		        }
		    });
		    $("#filter-count").text(count);
		});
		
			// bind events to trash to empty all lists
		$(elmts.emptyX).on('click', function() {
			$('#sortable2 > li').each(function() {
				var clone = $(this).clone(true);
				$('#sortable1').append(clone);
				$(this).remove();
			});
		});
		$(elmts.emptyY).on('click', function() {
			$('#sortable3 > li').each(function() {
				var clone = $(this).clone(true);
				$('#sortable1').append(clone);
				$(this).remove();
			});
		});
}