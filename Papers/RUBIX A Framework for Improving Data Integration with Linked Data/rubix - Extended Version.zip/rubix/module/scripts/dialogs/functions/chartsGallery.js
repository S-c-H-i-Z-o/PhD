function chartGallery() {
	
}
