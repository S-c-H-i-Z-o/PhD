//Global Variables for the Matching Table
var autoCompleteTarget;
var autoCompletesource;
var matchedItems = new Array(); //This variable is to keep track of the matched elements (Size 0: No Matching was done)
//Note that the path to put images in for JavaScript is [Refine Root]\main\webapp\modules\core\images
var asInitVals = new Array(); // Variable used to save elements used in filtering
var autoCompleteArray = [new Array(),new Array()]; //AutoComplete Array: [0] --> Source, [1] --> Target

function matchingTable(response) {
	this._createTable(response);
}

matchingTable.prototype._createTable = function(response) {
	console.log(response); //Logging the JSON in the console
	//Datatable requires data to be in a Javascript array : As a result we will parse the JSON and fill our Array
	var matches = []; //The Javascript Array that will contain our elements
	for ( var result in response) { // Loop to parse JSON object and create JavaScript array
		matches.push([
						response[result].OptionsIcon, // Push the options icons into the JavaScript Array
						response[result].SourceColumn_html, //Push the source element ("String Filled with <span> to enable editable")
						response[result].TargetColumn_html, //Push the target element ("String Filled with <span> to enable editable")
						response[result].Similarity, //Push the Similarity Result 
						response[result].ToolsIcon, //Push the toolIcons (Match, UnMatch, Delete) 
						response[result].ID,  //Push the Result which is the index of the elements
						response[result].SourceColumn, //Push the Source String without filling --> This is our Main source element
						response[result].TargetColumn, //Push the target String without filling --> This is our Main target element
						null, //This is the new Edited Value --> In the beginning it is null , it will be filled if a match is done
						response[result].Similarity ]//This is the Similarity Repeated --> This is used to revert back to the old value when undo is clicked
						);		
		if (response[result].SourceColumn != null)autoCompleteArray[0].push(response[result].SourceColumn); // Creating an array with source data for autocompletion
		if (response[result].TargetColumn != null)autoCompleteArray[1].push(response[result].TargetColumn); // creating an array with target data for autocompletion		
	}
	if (!matches.length) {
		alert("No Valid Matches Were Found !! ");
	}

	// Create the extra details row --> Currently it is filled with dummy data (Shall be replaced when received from the server)
	function fnFormatDetails(aPos) {
		var sOut = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
		sOut += '<tr><td><span style="font-weight:bold">Source Documentation:</span><p id="documentation">' + response[aPos[0]].Extra_Information.Source_Documentation + '</p></td><td> </td></tr>';
		sOut += '<tr><td><span style="font-weight:bold">Target Documentation:</span><p id="documentation">' + response[aPos[0]].Extra_Information.Target_Documentation + '</p></td><td> </td></tr>';
		sOut += '</table>';
		return sOut;
	}

	// Initializing AMC Table
	//Check http://datatables.net/usage/options for more info on parameters
	oTable = $(elmts.dialogTable).dataTable(
		{
			"sDom" : 'Rlf<"clear"><"toolbar">rtip', //This initialization variable allows you to specify exactly where in the DOM you want DataTables to inject the various controls it adds to the page 
			"sScrollY" : 600, // This setting is for viewing the table and when to show the scrollbar
			"sScrollX" : "99%", //This setting is to control if a horizontal toolbar is needed and when to show it
			"sScrollXInner" : "99%", //This property can be used to force a DataTable to use more width than it might otherwise do when x-scrolling is enabled
			"sPaginationType" : "full_numbers", //Control the pagination style
			"aaData" : matches, //This is our data source --> The JavaScript array parsed from JSON
			"aaSorting" : [ [ 3, 'desc' ] ], //Define the sorting column and the sorting order
			"iDisplayLength" : 25, // How many items to display //define how many rows to display in each page
			"aLengthMenu" : [ [ 25, 50, 100, -1 ], //This parameter allows you to readily specify the entries in the length drop down menu that DataTables shows when pagination is enabled 
					[ 25, 50, 100, "All" ] ],
			"bSortCellsTop" : true,
			/* Define columns and their styles
			 * 		sWidth: Define the columns width
			 * 		sClass: Define CSS to be applied to column`s content (Pre-defined Classes)
			 * 		sTitle: Define the Column`s Header
			 */
			"aoColumns" : [ { 						
				"sWidth" : "1%", 
				"sClass" : "center", 
			}, {
				"sTitle" : "Source Column", 
				"sClass" : "left",
				"sWidth" : "36%"
			}, {
				"sTitle" : "Target Column",
				"sClass" : "left",
				"sWidth" : "36%"
			}, {
				"sTitle" : "Similarity",
				"sClass" : "center",
				"sWidth" : "17%"
			}, {
				"sWidth" : "10%",
				"sClass" : "center",
			}, {
			// This is the Row ID Column
			}, {
				"sTitle" : "Old Source Column"
			}, {
				"sTitle" : "Old Target column"
			}, {
				"sTitle" : "New Value"
			} ],
			
			/* This array allows you to target a specific column, multiple columns, or all columns
			 * 		aTargets: target specific columns with the definition given
			 * 		bSortable: Enable or disable sorting on this column
			 * 		bVisible: 						 
			 */						
			"aoColumnDefs" : [ {
				"bSortable" : false,
				"aTargets" : [ 0 , 4]
			}, 
			{
				"bSortable" : false,
				"bVisible" : false,
				"aTargets" : [5,6,7,8,9]
			}],
			
			"fnDrawCallback" : function() {
				// Adding Auto complete + Custom Source for the Source Column
				$.editable.addInputType('autocompleteTarget', {
						element : $.editable.types.text.element,
						plugin : function(settings,original) {
							autoCompleteSource = $('input', this).autocomplete({
												source : autoCompleteArray[0] });
						}
					});
				// Adding Auto complete + Custom Source for the Target Column
				$.editable.addInputType('autocompleteSource', {
						element : $.editable.types.text.element,
						plugin : function(settings,original) {
							autoCompleteTarget = $('input', this).autocomplete({
												source : autoCompleteArray[1] });
						}
					});				
				// Adding the jEditable Plugin for Source
				$('#source', '#result-table tbody td').editable(function(value, settings) {
					return (value); 
					},
					{
						"callback" : function(sValue, y) {
							var aPos = oTable.fnGetPosition(this.parentNode);
							if (sValue != '') {
								if (oTable.fnGetData(aPos[0])[6] != null) {
									if (oTable.fnGetData(aPos[0])[6] != sValue) {
										oTable.fnUpdate(sValue,aPos[0],8);
										oTable.fnUpdate(oTable.fnGetData(aPos[0])[aPos[1] + 5] 
										+ '<img class="controlImage" src="images/arrow_right.png"/>'
										+ sValue,aPos[0],aPos[1]);
									}
								} else {												
									oTable.fnUpdate(sValue,aPos[0], 6);
									oTable.fnUpdate(sValue,aPos[0],aPos[1]);
								}
								autoCompleteArray[1].push(sValue);
							} else if (oTable.fnGetData(aPos[0])[6] != null) {
								oTable.fnUpdate(oTable.fnGetData(aPos[0])[6],aPos[0],aPos[1]);
							} else {
								alert("Please Provide a Valid Entry for Source Column");
							}
						},
						"submitdata" : function(value,settings) {
							return {
								"row_id" : this.parentNode.getAttribute('id'),
								"column" : oTable.fnGetPosition(this)[2]
							};
						},
						"height" : "20px",
						type : "autocompleteSource",
						tooltip : "Click to Edit ...",
						onblur : "ignore",
						submit : ' ',
						cancel : ' ',
						select : true,
						loadtext : 'Loading suggestions ...'
					});
				$('#target', '#result-table tbody td').editable(
					function(value, settings) {
						return (value);
					},
					{
						"callback" : function(sValue, y) {													
							var aPos = oTable.fnGetPosition(this.parentNode);
							if (sValue != '') {
								if (oTable.fnGetData(aPos[0])[7] != null) {
									if (oTable.fnGetData(aPos[0])[7] != sValue) {
										oTable.fnUpdate(sValue,aPos[0],8);
										oTable.fnUpdate(oTable.fnGetData(aPos[0])[aPos[2] + 5]
										+ '<img class="controlImage" src="images/arrow_right.png"/>'
										+ sValue,aPos[0],aPos[1]);
									}
								} else {
									oTable.fnUpdate(sValue,aPos[0], 7);
									oTable.fnUpdate(sValue,aPos[0],aPos[1]);
								}
								autoCompleteArray[0].push(sValue);
							} else if (oTable.fnGetData(aPos[0])[7] != null) {
								alert("Please Enter a Valid String");
								oTable.fnUpdate(oTable.fnGetData(aPos[0])[7],aPos[0],aPos[1]);
							} else {
								alert("Please Provide a Valid Entry for Target Column");
							}
						},
						"submitdata" : function(value,settings) {
							return {
								"row_id" : this.parentNode.getAttribute('id'),
								"column" : oTable.fnGetPosition(this)[2]
							};
						},
						"height" : "20px",
						type : "autocompleteTarget",
						tooltip : "Click to Edit ...",
						onblur : "ignore",
						submit : ' ',
						cancel : ' ',
						select : true,
						loadtext : 'Loading suggestions ...'
					});
				setTimeout(function() { 
					fnMaintainCSS(); 
					}, 0);
			}
		});

	// The toolbar Elements (Show/Hide Matched Rows)
	var toolbarContents = '<span class="toolbar_icon" id="hide"><img class="handcursor" src="images/arrow_down.png"/>  Hide Matched Columns </span>';
	toolbarContents += '<span class="toolbar_icon" id="show"><img class="handcursor" src="images/arrow_up.png"/>  Show Matched Columns </span>';
	toolbarContents += '<span class="toolbar_icon" id="refresh"><img class="handcursor" src="images/arrow_refresh.png"/>  Refresh Table </span>';
	$("div.toolbar").html(toolbarContents);

	// Attaching functions to the Toolbar
	$('#addEntry').click(function() {
		alert('Adding Entry');
	});
	$('#hide').click(function() {
		hideMatchedRows();
	});
	$('#show').click(function() {
		showMatchedRows();
	});
	$('#refresh').click(function() {
		oTable.fnDraw();
	});
		
	// Attaching Functionalities on images clicks
	oTable.find('tbody tr img').live('click', function() {
		var aPos = oTable.fnGetPosition(this.parentNode);
		var nTr = this.parentNode.parentNode;
		if (this.src.match('arrow_right')) { 
			matchSourceResult(aPos[0], nTr);
		} else if (this.src.match('arrow_left')) {
			matchTargetResult(aPos[0], nTr);
		} else if (this.src.match('delete')) {
			unMatchResult(aPos[0], nTr);
		} else if (this.src.match('cross')) {
			oTable.fnDeleteRow(aPos[0]);
		} else if (this.src.match('arrow_undo')) {
			undo(aPos[0], nTr);
		} else if (this.src.match('error')) {
			alert("Please Fill in the Required Fields ... ");
		} else if (!this.src.match('accept')) {
			if (this.src.match('details_close')) {
				/* This row is already open - close it */
				this.src = "images/details_open.png";
				oTable.fnClose(nTr);
			} else {
				/* Open this row */
				//Adding Editable function to the Documentation Fields
				this.src = "images/details_close.png";
				oTable.fnOpen(nTr, fnFormatDetails(aPos), 'details');
				oTable.find('#documentation').each(function() {
					$(this).editable(function(value, settings) {
						return (value);
					}, {
						"submitdata" : function(value, settings) {
							return {
								"row_id" : this.parentNode.getAttribute('id'),
								"column" : oTable.fnGetPosition(this)[2]
							};
						},
						"height" : "20px",
						tooltip : "Click to Edit ...",
						onblur : "ignore",
						submit : ' ',
						cancel : ' ',
						select : true,
					});
				});
			}
		}
	});


	// initialize the accordion for the Dialog - it is done after the table
	// initialization to obtain the table`s width
	$(elmts.accordion).accordion({
		autoHeight : false
	});
	$(elmts.accordion).accordion("option", "active", 0);
	
	// Adding Row/Column highlighting functionality
	$($(elmts.dialogTable).find('td'), oTable.fnGetNodes()).hover(function() {
		var iCol = $('td', this.parentNode).index(this) % 5;
		var nTrs = oTable.fnGetNodes();
		$('td:nth-child(' + (iCol + 1) + ')', nTrs).addClass('highlighted');
	}, function() {
		$('td.highlighted', oTable.fnGetNodes()).removeClass('highlighted');
	});

	// Adding Filtering Elements
	$('thead input').each(function(i) {
		asInitVals[i] = this.value;
	});
	// Empty the Input Element when having focus In
	$('thead input').live('focus', function() {
		if (this.className == "search_init") {
			this.className = "";
			this.value = "";
		}
	});

	$('thead input').live('blur', function(i) {
		if (this.value == "" && this.className != "compare") {
			this.className = "search_init";
			this.value = asInitVals[$('thead input').index(this)];
		}
	});

	// Filter when writing in the input Element
	$('thead input').live('keyup', function() {
		/*
		 * Filter on the column (the index) of this element note that the index
		 * is incremented by one due to the hidden column in the beginning
		 */
		if (this.className != "compare") {
			oTable.fnFilter(this.value, $('thead input').index(this) + 1);
		}
	});

	// Adding support for filtering on a range in the Similarity column
	$.fn.dataTableExt.afnFiltering.push(function(oSettings, aData, iDataIndex) {
		var iMin = document.getElementById('min').value * 1;
		var iMax = document.getElementById('max').value * 1;
		var iVersion = aData[3] == "-" ? 0 : aData[3] * 1;
		if (iMin == "" && iMax == "") {
			return true;
		} else if (iMin == "" && iVersion <= iMax) {
			return true;
		} else if (iMin <= iVersion && "" == iMax) {
			return true;
		} else if (iMin <= iVersion && iVersion <= iMax) {
			return true;
		}
		return false;
	});
	// Range selection filtering
	$('#min').keyup(function() {
		oTable.fnDraw();
	});
	$('#max').keyup(function() {
		oTable.fnDraw();
	});
};


// Undo matching by reverting to the original old values for source and target
function undo(rowID, nTr) {
	oTable.fnUpdate("<span id=\"source\">" + oTable.fnGetData(rowID)[6]+ "</span>", rowID, 1,false);
	oTable.fnUpdate("<span id=\"source\">" + oTable.fnGetData(rowID)[7]+ "</span>", rowID, 2,false);
	oTable.fnUpdate(oTable.fnGetData(rowID)[9], rowID, 3,false);
	oTable.fnUpdate(null, rowID, 8,false);
	oTable.fnUpdate(
					'<img class="handcursor" title="Match With Source" alt="Match with Source" src="images/arrow_right.png"/>  <span>'
							+ '</span><img class="handcursor" title="UnMatch Columns" alt="UnMatch Columns" src="images/delete.png"/>  <span> '
							+ '</span><img class="handcursor" title="Match With Target" alt="Match with Target" src="images/arrow_left.png"/>'
							+ '<span>&nbsp;</span><img class="handcursor" title="Delete" alt="Delete" src="images/cross.png"/>',
					rowID, 4,false);
	oTable.fnDraw(false);
	$(nTr).removeClass().addClass('redo');
	removeByElement(matchedItems,rowID);
}

// Match the selected column with Source (highlight + change column name)
function matchSourceResult(rowID, nTr) {
	var aData = oTable.fnGetData(rowID);
	if (aData[6] || aData[8] != null) {
		if (aData[7] || aData[8] != null) {
			if (!aData[8]) {
				oTable.fnUpdate(oTable.fnGetData(rowID)[6], rowID, 8,false);
				oTable.fnUpdate('[ '+ aData[7] + ' ]' + '<img class="controlImage" src="images/arrow_right.png"/>'
									+ aData[6] + '<img class="controlImage" src="images/asterisk_yellow.png"/>', rowID, 2,false);
				oTable.fnUpdate(oTable.fnGetData(rowID)[6], rowID, 1,false );
				oTable.fnUpdate('1.0', rowID, 3,false);
				oTable.fnUpdate( '<img class="controlImage" src="images/accept.png" title="Matched"/><img class="controlImage" src="images/arrow_undo.png" title="Undo"/>', rowID, 4,false);
				$(nTr).removeClass().addClass('accepted');
				$(nTr).attr("id", "AcceptedRow");
				oTable.fnDraw(false);
				matchedItems.push(rowID);
			} else {
				oTable.fnUpdate('[ '+ aData[7] + ' ]' + '<img class="controlImage" src="images/arrow_right.png"/>'
									+ aData[8] + '<img class="controlImage" src="images/asterisk_yellow.png"/>', rowID, 2,false);
				oTable.fnUpdate(aData[8], rowID, 8,false);
				oTable.fnUpdate('1.0', rowID, 3,false);
				oTable.fnUpdate( '<img class="controlImage" src="images/accept.png" title="Matched"/><img class="controlImage" src="images/arrow_undo.png" title="Undo"/>', rowID, 4,false);
				$(nTr).removeClass().addClass('accepted');
				$(nTr).attr("id", "AcceptedRow");
				oTable.fnDraw(false);
				matchedItems.push(rowID);
			}
		} else {
			alert("Please Fill in the Target Column Data ...");
		}
	} else {
		alert("Please Fill in Source Data");
	}

}

// Match the selected column with Target (highlight + change column name)
function matchTargetResult(rowID, nTr) {
	var aData = oTable.fnGetData(rowID);
	if (aData[7] || aData[8] != null) {
		if (aData[8] || aData[6] != null) {
			if (!aData[8]) {
				oTable.fnUpdate(oTable.fnGetData(rowID)[7], rowID, 8,false);
				oTable.fnUpdate('[ ' + aData[6] + ' ]' + '<img class="controlImage" src="images/arrow_right.png"/>'
									+ aData[7] + '<img class="controlImage" src="images/asterisk_yellow.png"/>', rowID, 1,false);
				oTable.fnUpdate(oTable.fnGetData(rowID)[7], rowID, 2,false);
				oTable.fnUpdate('1.0', rowID, 3,false);
				oTable.fnUpdate( '<img class="controlImage" src="images/accept.png" title="Matched"/><img class="controlImage" src="images/arrow_undo.png" title="Undo"/>', rowID, 4,false);
				$(nTr).removeClass().addClass('accepted');
				$(nTr).attr("id", "AcceptedRow");
				oTable.fnDraw(false);
				matchedItems.push(rowID);
			} else {
				oTable.fnUpdate( '[ ' + aData[6] + ' ]' + '<img class="controlImage" src="images/arrow_right.png"/>'
									+ aData[8] + '<img class="controlImage" src="images/asterisk_yellow.png"/>', rowID, 1,false);
				oTable.fnUpdate('1.0', rowID, 3,false);
				oTable.fnUpdate(aData[8], rowID, 8,false);
				oTable.fnUpdate( '<img class="controlImage" src="images/accept.png" title="Matched"/><img class="controlImage" src="images/arrow_undo.png" title="Undo"/>', rowID, 4, false);
				$(nTr).removeClass().addClass('accepted');
				$(nTr).attr("id", "AcceptedRow");
				oTable.fnDraw(false);
				matchedItems.push(rowID);
			}
		} else {
			alert("Please Fill in the Source Column Data ...");
		}
	} else {
		alert("Please Fill in Target Data");
	}
}

// unMatch the selected column (highlight + change column name)
function unMatchResult(rowID, nTr) {
	var aData = oTable.fnGetData(rowID);
	if (aData[1] == "<span id=\"source\" class=\"toEdit\"></span>" || aData[2] == "<span id=\"target\" class=\"toEdit\"></span>") {
		alert("Sorry .. Cannot unmatch this column !!")
	} else {
		oTable.fnDeleteRow(rowID);
		oTable.fnAddDataAndDisplay(['<img src="images/details_open.png">',aData[1],
		                  '<p id = "target" class="data toEdit"></p>',0,
						'<img class="handcursor" src="images/arrow_right.png"><span></span><img class="handcursor" src="images/arrow_left.png">'
						+ '<span></span><img class="controlImage" src="images/error.png">',
						oTable.fnSettings().fnRecordsTotal(), aData[6], null, null, null ]);
		oTable.fnAddDataAndDisplay([
						'<img src="images/details_open.png">',
						'<p id = "source" class="data toEdit"></p>',aData[2],
						0,'<img class="handcursor" src="images/arrow_right.png"><span></span><img class="handcursor" src="images/arrow_left.png">'
						+ '<span></span><img class="controlImage" src="images/error.png">',
						oTable.fnSettings().fnRecordsTotal()+1, null, aData[7], null, null] );
		oTable.fnDraw(false);
	}
}


// Hide Matched Rows
function hideMatchedRows() {
	var aTrs = oTable.fnGetNodes();
	for ( var i = 0; i < aTrs.length; i++) {
		if ($(aTrs[i]).hasClass("accepted")) {
			$(aTrs[i]).hide();
		}
	}
}

// Show Matched Rows
function showMatchedRows() {
	var aTrs = oTable.fnGetNodes();
	for ( var i = 0; i < aTrs.length; i++) {
		if ($(aTrs[i]).hasClass("accepted")) {
			$(aTrs[i]).show();
			matchingDone = true;
		}
	}
}

/* This function is called whenever the table is redrawn. It is used to maintain the row highlights and different
 * othee CSS classes --> Called when Refresh button is hit.
 */
function fnMaintainCSS() {
	var aTrs = oTable.fnGetNodes();
	for ( var i = 0; i < aTrs.length; i++) {
		if ($(aTrs[i]).hasClass("accepted")) {
			$(aTrs[i]).removeClass().addClass('accepted');
		}
	}
	oTable.find('tbody tr img').each(function() {
		var aPos = oTable.fnGetPosition(this.parentNode);
		var nTr = this.parentNode.parentNode;
		if (this.src.match('error')) {
			$(nTr).removeClass().addClass('toMatch');
		}
	});
}
