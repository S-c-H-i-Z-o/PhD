var elmts;  //Global Variable that holds the DOM elements
var oTable; //Global Element that will save the Datatable
var json = "[ "; //The JSON String that will be sent to the server side containing the matched column names
var columnsArray = new Array();
var columnsJSON = "[ ";
var cat = new Array();
var chartingData = new Array();


// function call for dialog creation
function amcDialog(id,option) {
	this._createDialog(id,option);
}

// Create dialog body
amcDialog.prototype._createDialog = function(id,option) {
	var self = this;
	var dialog = $(DOM.loadHTML("amc-refine", "scripts/dialogs/amc-dialog.html")); // Load DOM Elements
	elmts = DOM.bind(dialog);
	var level = DialogSystem.showDialog(dialog);
	var dismiss = function() {
		DialogSystem.dismissUntil(level - 1);
	};
	
	// Adding events handlers to the button (Work-flow Control)
	// Button merge Function onClick()
	$('#merge').live('click', function() { 
		if (matchedItems.length > 0) {
			$("#div-accordion").accordion("option", "active", 1);
			chartGallery();
			createJSON();
			createColumnsList();
			dragAndDrop();
			AmcExtension.handlers.runMerge(json, id);
			//Change the button Text and ID
			$('#merge').text("Visualize");
			$('#merge').attr("id", "vis");
		} else {
			alert("Please match at Least one Column ...");
		}

	});
	// Adding events handlers to the button (Work-flow Control)
	// Button visualize Function onClick()
	$('#vis').live('click',function() { 
		//Convert the items collected in the drop zones into arrays
		var x = ($('#sortable2').sortable('toArray')); //The first drop zone for the X-Axis
		var y = ($('#sortable3').sortable('toArray')); //The Second drop zone for the y-Axis
		if (x.length > 1 && y.length > 1) {

				columnsArray = ((x.slice(1,x.length)).concat(y.slice(1,y.length)));
				createColumnsJSON();
				sendColumns();
				$("#div-accordion").accordion("option", "active", 2);
		
		} else {
			alert("Please Select columns for both X and Y axises");
		}

	});
	elmts.cancelButton.click(function() { // button Cancel function
		dismiss();
	});

	this._prepAmcDialog(id,option);
};


/* This function prepares the list of columns to be shown as tags in order to be dragged for charting
 * The function looks for new values for the source column, if they exist they will be sent as the new value
 * The ID is always set to the old value is it is the reference for the column name with the Server Side
 */
function createColumnsList() {
	/*
	 * Setting The CSS Classes to match the following Cases: matchedTag : The
	 * column Name is matchedTag --> Change the background color to Green
	 * NewColumnMatched: New Names will have blue background with Green Border
	 * newColumn : Change the background color to blue
	 */
	for ( var i = 0; i < oTable.fnGetNodes().length; i++) {
		var cssClass = "ui-state-default";
		if (oTable.fnGetData(i)[8] != null) {
			if (inArray(i, matchedItems, true)) {
				cssClass += " matchedTag";
				if (oTable.fnGetData(i)[8] != oTable.fnGetData(i)[6]) {
					cssClass += " matchedNew";
				}
			} else {
				cssClass += " newColumn";
			}
			$(elmts.columnList).append(
					"<li class=\"" + cssClass + "\" id=\""
							+ oTable.fnGetData(i)[6] + "\">"
							+ oTable.fnGetData(i)[8] + "</li>");
		} else if (oTable.fnGetData(i)[6] != null) {
			$(elmts.columnList).append(
					"<li class=\"" + cssClass + "\" id=\""
							+ oTable.fnGetData(i)[6] + "\">"
							+ oTable.fnGetData(i)[6] + "</li>");
		}
	}

}

// Send the column Names
function sendColumns() {
	params = {
		"columns" : columnsJSON
	};
	callbacks = {
		"onDone" : function(response) {
			prepChart(response);
			charting(response);
		}
	}
	Refine.postProcess("amc-refine", "get-column-values", params, {}, {},
			callbacks);
};

//Do The Charting Part
function prepChart(response) {
	// this is where we can loop through the results in the json object
	$.each(response.Categories, function(i,obj){
		cat.push(obj);
	});
	for ( var result in response) {
		chartingData.push(response[result]);
		console.log(response[result]);
		console.log("Logging Charting Data " + chartingData);
	}
}


// Calling AMC and retrieving the JSON Object for the matching table
amcDialog.prototype._prepAmcDialog = function(target,option) {
	//Parameters Sent to the Servlet (The ID of the target Project)
	params = {
		"targetProject" : target,
		"option" : option
	};
	//Callback function upon the successful retrieval of the JSON file from the back-end
	callbacks = { 
		"onDone" : function(response) {
			//Create Matching table and send the JSON object received as parameter from the Servlet
			new matchingTable(response);
		}
	}	
	//Call the function registered in Controller.JS
	Refine.postProcess("amc-refine", "amc-refine", params, {}, {}, callbacks);
}

/* This function creates a JSON object that contains the mapping elements as required by the server
 * The JSON is created by constructing a string and looping through elements and pushing that string 
 * into an array. The slice is to delete the trailing comma at the end of the file.
 * IMP: Note that the column names sent are only for the matched elements
 */
var createJSON = function() {
	for ( var i = 0; i < matchedItems.length; i++) {
			json += "{" + '"oldSource" : ' + '"' + oTable.fnGetData(matchedItems[i])[6] + '"'
					+ ", " + '"oldTarget" : ' + '"' + oTable.fnGetData(matchedItems[i])[7]
					+ '"' + ", " + '"newColumn" : ' + '"'
					+ oTable.fnGetData(matchedItems[i])[8] + '"' + "},";
	}
	json = json.slice(0, (json.length) - 1);
	json += " ]";
	console.log(json);
}


var createColumnsJSON = function() {
	for ( var i = 0; i < columnsArray.length; i++) {
			columnsJSON += '"' +columnsArray[i] + '"'
					+ ",";
	}
	columnsJSON = columnsJSON.slice(0, (columnsJSON.length) - 1);
	columnsJSON += " ]";
	console.log(columnsJSON);
}
