var AmcExtension = {
	handlers : {}
};

AmcExtension.handlers.prepProjectDialog = function() {
	new matchingDialog();
};

AmcExtension.handlers.prepAmcDialog = function(id,option) {
	new amcDialog(id,option);
};

AmcExtension.handlers.runMerge = function(matches, ID) {
	params = {
		"targetProject" : ID,
		"matches" : matches
	};
	Refine.postProcess("amc-refine", "merge-projects", params, {}, {}, {});
};

ExtensionBar.MenuItems.push({
	"id" : "amc-refine",
	"label" : "Automatic Matching",
	"submenu" : [ {
		"id" : "amc-refine/load-from-project",
		label : "Load From Project",
		click : function() {
			AmcExtension.handlers.prepProjectDialog();
		}
	}, {
		"id" : "amc-refine/load-from-file",
		label : "Load From File",
		click : function() {
			alert("Function not Implemented Yet ... Sorry");
		}
	}]
});
