package com.sap.research.rubix.refine;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.refine.ProjectManager;
import com.google.refine.commands.Command;
import com.google.refine.importers.ImporterUtilities;
import com.google.refine.io.ProjectUtilities;
import com.google.refine.model.Cell;
import com.google.refine.model.Column;
import com.google.refine.model.Project;
import com.google.refine.model.Row;

public class MergeProjects extends Command {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	};

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
        
		try {

			ProjectManager.singleton.setBusy(true);
			Project sourceProject = getProject(request);

			Project targetProject = null;

			String targetProjectID = request.getParameter("targetProject");
			if (targetProjectID != null) {
				long id = Long.parseLong(targetProjectID);
				targetProject = ProjectManager.singleton.getProject(id);
			}
			

			List<String> columnNames = sourceProject.columnModel.getColumnNames();
			int numberColumns = columnNames.size();
			boolean hasOurOwnColumnNames = true;
			
//			Handle incoming match results in JSON format

			Gson gson = new Gson();
			
			String json = request.getParameter("matches");
			
			Type collectionType = new TypeToken<Collection<ColumnMatch>>(){}.getType();
			Collection<ColumnMatch> colMatches = gson.fromJson(json, collectionType);
			
			if (colMatches.size() > 0){

				for (int numRows = 0; numRows < targetProject.rows.size(); numRows++) {
					Row row = new Row(numberColumns);
					
					for (int c = 0; c < numberColumns; c++) {
						Column column = ImporterUtilities
								.getOrAllocateColumn(sourceProject, columnNames, c,
										hasOurOwnColumnNames);

						ColumnMatch currentMatch = getMatchFromSource(colMatches,
								column.getName());

						if (null == currentMatch) {
							row.setCell(column.getCellIndex(), new Cell("", null)); //add empty string
						} else if ( "null".equals(currentMatch.getOldTarget()) ) {
							row.setCell(column.getCellIndex(), new Cell("", null)); //add empty string
						} else {
							Column targetcolumn = targetProject.columnModel
							.getColumnByName(currentMatch.getOldTarget());
							Cell cell = targetProject.rows.get(numRows).getCell(targetcolumn.getCellIndex());
							if(null == cell) {
								row.setCell(column.getCellIndex(), new Cell("", null)); //add empty string
							} else {
								row.setCell(column.getCellIndex(), new Cell(cell.value, cell.recon));
							}
						}
						
					}
					sourceProject.rows.add(row);
				}
				

				sourceProject.recordModel.update(sourceProject);
				ProjectUtilities.save(sourceProject);	
			}		

		} catch (Exception e) {
			respondException(response, e);
		} finally {
			ProjectManager.singleton.setBusy(false);
		}
	}
	
	private ColumnMatch getMatchFromSource(Collection<ColumnMatch> matches,
			String oldSource) {

		for (ColumnMatch m : matches) {
			if (!"null".equals(m.getOldSource())) {
				if(null != m.getOldSource()) {
					if (m.getOldSource().equals(oldSource)) {
						return m;
					}
				}				
			}
		}

		return null;
	}
}
