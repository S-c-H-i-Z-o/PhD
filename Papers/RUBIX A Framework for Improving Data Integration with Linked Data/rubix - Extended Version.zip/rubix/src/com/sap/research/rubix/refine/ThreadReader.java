//package com.sap.research.rubix.refine;
//
//import java.io.IOException;
//
//import org.json.JSONException;
//
//public class ThreadReader implements Runnable{
//	
//	
//	String freebaseAddress,keyword;
//	
//
//	public ThreadReader(String freebaseAddress, String keyword) {
//		super();
//		this.freebaseAddress = freebaseAddress;
//		this.keyword = keyword;
//	}
//
//
//	@Override
//	public void run() {
//		FreebaseReader fr = new FreebaseReader();
//		try {
//			FreebaseReader.json = fr.readJsonFromUrl(freebaseAddress + keyword.replaceAll(" ", "%20"));
//		} catch (IOException | JSONException e) {
//			// TODO Auto-generated catch block
//			System.err.println("Error in Thread Reader");
//			e.printStackTrace();
//		}
//	}
//
//}
