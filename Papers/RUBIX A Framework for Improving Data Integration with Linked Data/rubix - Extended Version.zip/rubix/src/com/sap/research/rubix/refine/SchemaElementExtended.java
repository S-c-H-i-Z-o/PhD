package com.sap.research.rubix.refine;

import java.util.HashMap;

import com.sap.research.amc.schema.impl.SchemaElementImpl;

public class SchemaElementExtended extends SchemaElementImpl {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private HashMap<String,Integer> recognizedTypes = new HashMap<String, Integer>();

	public void setRecognizedTypes(HashMap<String,Integer> recognizedTypes) {
		this.recognizedTypes = recognizedTypes;
	}

	public HashMap<String,Integer> getRecognizedTypes() {
		return recognizedTypes;
	}

}
