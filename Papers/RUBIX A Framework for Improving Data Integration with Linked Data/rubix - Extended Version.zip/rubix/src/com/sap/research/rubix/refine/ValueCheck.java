package com.sap.research.rubix.refine;

public class ValueCheck {
	
	boolean match;
	String type;
	
	
	public ValueCheck(boolean match, String type) {
		super();
		this.match = match;
		this.type = type;
	}
	public ValueCheck() {
	}
	public boolean isMatch() {
		return match;
	}
	public String getType() {
		return type;
	}
	
	public void setValues (boolean check, String type) {
		this.match = check;
		this.type = type;
	}

}
