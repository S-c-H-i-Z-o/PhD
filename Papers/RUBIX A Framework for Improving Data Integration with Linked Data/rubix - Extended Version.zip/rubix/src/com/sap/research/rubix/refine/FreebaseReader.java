package com.sap.research.rubix.refine;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class FreebaseReader {
	
	static HashMap<String, HashMap<String, Double>> rowsCache = new HashMap<String, HashMap<String,Double>>();
	String freebaseAddress = "https://www.googleapis.com/freebase/v1/search?query=";
	
	private String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public JSONObject readJsonFromUrl(String url) throws IOException,
			JSONException {
		InputStream is = new URL(url).openStream();
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is,
					Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			JSONObject json = new JSONObject(jsonText);
			return json;
		} finally {
			is.close();
		}
	}
	
	public HashMap<String, Double> fetchTypes(String keyword) throws IOException, JSONException, InterruptedException {
	    JSONObject json;
		HashMap<String, Double> rich_types = new HashMap<>();
		System.setProperty("https.proxyHost", "proxy");
		System.setProperty("https.proxyPort", "8080");
		if (keyword.trim().length() > 0 && 
				!keyword.equals(null) && !keyword.trim().equals(null) && !keyword.trim().equals("")) {
			    rich_types = new HashMap<String, Double>();
				keywordChecker kw = new keywordChecker();
				ValueCheck vk = kw.keywordCheckerIterator(keyword.trim());
				System.out.println("+++++ We have checked the keyword " + keyword + " and it was matched: " + vk.isMatch() + " is of type " + vk.getType() + " +++++" );
				if (!vk.isMatch()) {
					if (!rowsCache.containsKey(keyword)) {
						json = readJsonFromUrl(freebaseAddress + keyword.replaceAll(" ", "%20") + "&key=AIzaSyCa58KRY6XmjxmMsiSBMXLKxsSBC3_Yf40");
						Thread.sleep(1000);						
						if (json.getJSONArray("result").length() != 0) {
							JSONArray array = json.getJSONArray("result");
							for (int i = 0; i < array.length(); i++) {
								if (array.getJSONObject(i).has("notable")) {
									JSONObject notable = new JSONObject(array.getJSONObject(i)
											.getString("notable"));
									if (!rich_types.containsKey(notable.getString("name"))){
										rich_types.put(notable.getString("name"), (Double) array.getJSONObject(i).get("score"));
										rowsCache.put(keyword, rich_types);
									}
								}
							}
						} else {
							System.out.println("== Entry not Found In Freebase but entered in cache ==");
							rich_types.put(keyword, 0.0); //The Entry is not in Freebase thus no related Confidence
							rowsCache.put(keyword, rich_types);
							System.out.print("[ Row Cached ]");
						}
					} else {
						System.out.print("[ Entry Found and retreived from Cache ]");
						rich_types = rowsCache.get(keyword);
					}
				} else {
					System.out.print("##### System has found a column with a matching regex Type #######> ");
					System.out.println(keyword + " Is of type " + vk.getType());
					if (!rich_types.containsKey((vk.getType()))){
						rich_types.put(vk.getType(), 100.00);
						rowsCache.put(keyword, rich_types);
					}
					rich_types.put(vk.getType(), 0.0);
					rowsCache.put(vk.getType(), rich_types);
					System.out.print("[ Row Cached ]");
				}

		} else {
			System.out.println("This Value is Null or Empty ======> Skip");
			rich_types.put("Empty", 0.0);
		}
		System.out.print(" The Result for " + keyword + " is: ");
		System.out.println(rich_types);
		return rich_types;
	}

}
