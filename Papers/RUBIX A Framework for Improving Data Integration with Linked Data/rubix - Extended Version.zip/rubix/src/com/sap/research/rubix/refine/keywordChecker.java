package com.sap.research.rubix.refine;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class keywordChecker {
	
	public ValueCheck keywordCheckerIterator(String keyword) {
		boolean check = false;
		String type = null;
		System.out.println("**** Checking The Keyword " + keyword + " Of Class : " + keyword.getClass());
		if (dateCheck(keyword)) {check = true; type="Date";} 
		else if (simpleDateCheck(keyword)) {check = true; type="Date";}
		else if (complexDateChecker(keyword)) {check = true; type="Date";}
		else if (codeCheck(keyword)) {check = true; type="Code";}
		else if (valueCheck(keyword)) {check = true; type="Number";}
		else if (simpleValue(keyword)) {check = true; type="Number";}
		else if (moneyCheck(keyword)) {check = true; type="Money";}
		return new ValueCheck(check,type);
	}
	
	public boolean complexDateChecker(String keyword) {
		boolean result = false;
	    String re1="((?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Sept|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?))";	// Month 1
	    String re2="(\\s+)";	// White Space 1
	    String re3="(\\d+)";	// Integer Number 1
	    String re4="(.)";	// Any Single Character 1
	    String re5="(\\s+)";	// White Space 2
	    String re6="((?:(?:[1]{1}\\d{1}\\d{1}\\d{1})|(?:[2]{1}\\d{3})))(?![\\d])";	// Year 1

	    Pattern p = Pattern.compile(re1+re2+re3+re4+re5+re6,Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
	    Matcher m = p.matcher(keyword);
	    result = m.find();
	    if (result) System.out.println(keyword + " Is a complex date/time"); else System.out.println(keyword + " Is not a complex date/time");
	    return result;
	}
	
	public boolean dateCheck(String keyword) {
		boolean result = false;
		 String re1="((?:(?:[1]{1}\\d{1}\\d{1}\\d{1})|(?:[2]{1}\\d{3}))[-:\\/.](?:[0]?[1-9]|[1][012])[-:\\/.](?:(?:[0-2]?\\d{1})|(?:[3][01]{1})))(?![\\d])";	// YYYYMMDD 1
		    String re2="([a-z])";	// Any Single Word Character (Not Whitespace) 1
		    String re3="((?:(?:[0-1][0-9])|(?:[2][0-3])|(?:[0-9])):(?:[0-5][0-9])(?::[0-5][0-9])?(?:\\s?(?:am|AM|pm|PM))?)";	// HourMinuteSec 1
		    String re4="([a-z])";	// Any Single Word Character (Not Whitespace) 2

		    Pattern p = Pattern.compile(re1+re2+re3+re4,Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		    Matcher m = p.matcher(keyword);
		    result = m.find();
		    if (result) System.out.println(keyword + " Is a complex date/time"); else System.out.println(keyword + " Is not a complex date/time");
		    return result;
	}
	
	public boolean simpleDateCheck(String keyword) {
		boolean result = false;
		  String re1="((?:[0]?[1-9]|[1][012])[-:\\/.](?:(?:[0-2]?\\d{1})|(?:[3][01]{1}))[-:\\/.](?:(?:[1]{1}\\d{1}\\d{1}\\d{1})|(?:[2]{1}\\d{3})))(?![\\d])";	// MMDDYYYY 1

		    Pattern p = Pattern.compile(re1,Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		    Matcher m = p.matcher(keyword);
		    result = m.find();
		    if (result) System.out.println(keyword + " Is a simple date"); else System.out.println(keyword + " Is not a simple date");
		    return result;
	}
	
	public boolean codeCheck(String keyword) {
		boolean result = false;
	    String re1="(\\d+)";	// Integer Number 1
	    String re2="(\\/)";	// Any Single Character 1
	    String re3="(\\d+)";	// Integer Number 2

	    Pattern p = Pattern.compile(re1+re2+re3,Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
	    Matcher m = p.matcher(keyword);
	    result = m.find();
	    if (result) System.out.println(keyword + " Is a Code"); else System.out.println(keyword + " Is not a Code");
	    return result;
	}
	
	public boolean simpleValue(String keyword) {
		boolean result = false;
	    String re1="(\\d+)";	// Integer Number 1
		Pattern p = Pattern.compile(re1,Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
	    Matcher m = p.matcher(keyword);
	    result = m.find();
	    if (result) System.out.println(keyword + " Is a simple value"); else System.out.println(keyword + " Is not a simple value");
	    return result;
	}
	
	public boolean valueCheck(String keyword) {
		boolean result = false;
	    String re1="(\\d+)";	// Integer Number 1
	    String re2="(.)";	// Any Single Character 1
	    String re3="(\\d+)";	// Integer Number 2

	    Pattern p = Pattern.compile(re1+re2+re3,Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
	    Matcher m = p.matcher(keyword);
	    result = m.find();
	    if (result) System.out.println(keyword + " Is a value"); else System.out.println(keyword + " Is not a value");
	    return result;
	}
	
	public boolean moneyCheck(String keyword) {
		boolean result = false;
	    String re1="(\\d+)";	// Integer Number 1
	    String re2="(,)";	// Any Single Character 1
	    String re3="(\\d+)";	// Integer Number 2

	    Pattern p = Pattern.compile(re1+re2+re3,Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
	    Matcher m = p.matcher(keyword);
	    result = m.find();
	    if (result) System.out.println(keyword + " Is money"); else System.out.println(keyword + " Is not money");
	    return result;
	}
}
